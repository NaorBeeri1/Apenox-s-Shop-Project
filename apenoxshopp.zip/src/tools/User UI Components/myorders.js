import React from 'react'
import Basket from '../Shop Components/Basket'
import ShoppingCart from '../Shop Components/artworks'

function MyOrders() {
  return (
    <div>
      {/* <ShoppingCart/> */}
    </div>
  )
}

export default MyOrders