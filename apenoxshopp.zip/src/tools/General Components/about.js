//imports
import React, { Component } from 'react';
import Footer from './Footer';
//
function About() {
  return (
    <>
    <div className='aboutinfo'>
    <h1>Hey! my name is Apenox i sell Artworks, Workshops, and Logos for your very own Steam profile showcase!</h1>
    <p>I sell works since the year of 2016, though this site was created at 2022 by my brother (Naor A.K.A Colix)</p>
    <p>This site was created due to my success in selling artworks and highly demanded arts that i create</p>
    <p>At the year of 2018 i became the highest rated seller on steam and the best selling one</p>
    <p>So what are you waiting for?</p>
    </div>
    <Footer />
    </>
  );
}
export default About;